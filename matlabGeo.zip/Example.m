
clear all;
clc;

Main_Catia('K:\matlabGeo',1);